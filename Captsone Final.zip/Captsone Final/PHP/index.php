<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        
        <title> Landing Page </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
    <div>   
           
        

        <h1>Welcome to our School's Home Page</h1>
        
        <div>
            <p>
                If this is the first time registering please click the restiration link. If not please log in using your credentials.
            </p>
            <nav>
                <ul>
                    <!-- <li><a href="home.php">Home Page</a></li> -->
                    <li><a href="login.php">Log In</a></li>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="contactUs.php">Contact Us</a></li>
                </ul>
            </nav>
        </div> 
        
        <hr>
        
        <nav>
            <p>Already have an account? <a href="login.php">Log in.</a></p>
        </nav>
    </div>
    </body>
</html>