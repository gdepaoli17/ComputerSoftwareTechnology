<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us Page</title>
</head>
<body>
    <div>
        <h1>Welcome to the Contact Us Page</h1>
        <hr>
        <div>
            <nav>
                <ul>
                    <li><a href="home.php">Home Page</a></li>
                    <!-- <li><a href="contactUs.php">Contact Us</a></li> -->
                    <!-- <li><a href="login.php">Log In</a></li> -->
                    <!--<li><a href="register.php">Register</a></li>-->
                </ul>
            </nav>
        </div> 
    </div>
</body>
</html>